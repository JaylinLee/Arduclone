#pragma once

const char* GetToolbarString(int index);
const char* GetMonthString(int index);

