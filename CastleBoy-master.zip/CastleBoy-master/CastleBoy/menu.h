#ifndef MENU_H
#define MENU_H

#include "global.h"

namespace Menu
{
  void showTitle();
  void notifyPlayerDied();
  void notifyLevelFinished();
  
  void loop();
}

#endif


